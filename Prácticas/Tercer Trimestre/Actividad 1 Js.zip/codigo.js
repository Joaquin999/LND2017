function myFunction() {
    var nombre;
    nombre = prompt("Nombre completo");
    //Introduzco la variable nombre y luego declaro que la variable será igual al resultado del promt
    alert("Bienvenido  " +nombre+"!"); 
    //Luego uso alert para decir que el navegador muestre la variable nombre además de "Bienvenido...!" 
    alert("Esto funciona loco");
}
